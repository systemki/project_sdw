 create database fruit;
 
 
  use fruit;

CREATE TABLE `fruit` (

	`fr_name`	varchar(15),
	`fr_price`	int	not NULL default 0,
	`fr_unit`	varchar(10)	not NULL default 'box',
	`tr_amount`	int	not NULL default 0,
    `fr_stock` int not null default 0,
	primary key(fr_name),
    check (fr_price >= 0 and fr_stock >= 0)
);

CREATE TABLE `trade` (
	`tr_num`	int	NOT NULL,
	`tr_amount`	int	NULL default 0,
	`tr_type`	varchar(4) not	NULL default'sell' ,
	`tr_price`	int	not NULL default 0,
	`tr_date`	datetime	not NULL default current_timestamp,
	`tr_fr_name`	varchar(15)	NOT NULL,
    primary key(tr_num),
    foreign key(tr_fr_name) references fruit(fr_name)
);
-- (a과수원에서) 사과 100상자 입고되었다. 상자당 가격은 10000원

insert into fruit values('사과',10000,'box',0,0);

select * from fruit;

insert into trade (tr_num, tr_amount, tr_type, tr_price, tr_fr_name)
values(1, 100, 'buy',1000000, '사과');

select * from trade;

update fruit set fr_amount =fr_amount + 100 where fr_name = '사과';

select * from fruit;

insert into trade (tr_num, tr_amount, tr_type, tr_price, tr_fr_name)
values(2, 1, 'sell',20000, '사과');

update fruit set fr_amount =fr_amount  - 1 where fr_name = '사과';

select * from trade;

select sum(tr_price) as '판매액' from trade where tr_type = 'sell' and tr_date like '2021-06-02%';

-- 총 매출액

/* case when 사용법
case when 조건1 then 실행
 when 조건2 then 반환값
else 실행 end as 속성명
*/

select sum(case when tr_type = 'buy' then -tr_price
	else tr_price = tr_price end) as '가격' from trade;


drop trigger if exists insert_trade;
delimiter //
create trigger insert_trade after insert on trade 
for each row

begin
if new.tr_type = 'buy' then 

update fruit set fr_amount =fr_amount - new.tr_amount where fr_name = new.tr_fr_name;
else 
update fruit set fr_amount =fr_amount + new.tr_amount where fr_name = new.tr_fr_name;
end if;

end // 
delimiter ;
 
insert into trade(tr_num, tr_amount, tr_type, tr_price, tr_fr_name) 
values(3, 10, 'sell',20000, '사과');

select * from fruit;


drop procedure if exists insert_buy;
delimiter //
create procedure insert_buy(
in _name varchar(15),
in _amount int,
in _price int,
in _sell_price int

)

begin 

declare _count int default 0; -- 구매 하려는 과일이 있는 없는지 확인 
declare _num int; 
 set _count = (select count(*) from fruit where fr_name = name);
 
 -- 해당 과일이 없으면 
	if _count = 0 then
    
	-- fruit 테이블에 과일을 추가(이떄, 판매가격 설정)
    insert into fruit(fr_name, fr_price)
		values(_name, _sell_price);
    end if;
    
    -- trade 테이블에 구매 내역 추가 
    set _num = (select max(tr_num) from trade) + 1;
    insert into reade(tr_num, tr_amount, tr_type, tr_price, tr_fr_name)
		values(_num, _amount, 'buy', _price, _name);

end //
delimiter ;

call insert_buy('포도', 100, 500000, 10000);
select * from fruit;





