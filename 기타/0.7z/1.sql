/* 
DCL -데이터 제어어
grant : 특정 데이터베이스 사용자에게 권한 부여 
revoke : 특정 데이터베이스 사용자에게 권한 회수
commit : 트랜잭션의 작업이 정상적으로 완료됨을 알려줌 
rollback : 트랜잭션 작업이 비정상적으로 완료 되었을 때 복구
*/


/* 정규화  :  데이터베이스를 효율적으로 관리하기 위해 데이터 중복을 제거하면서 무결성을 유지하기 위한 기법 
			 (큰테이블을 여러개의 쪼개기)
             
             제1정규화 : 속성의값이 원자값을 갖도록 테이블을 분해 
             제2정규화 : 완전 함수 종속을 만족 하도록 테이블을 분해
						기본키의 부분집합으로 속성을 검색하면 안된다.
             제3정규화 : 이행종속을 제거하도록 테이블을 분해 
						A > B , B > C, A > C가 성립 
             반정규화 : 정규화 테이블이 너무 많아서 검색할 때 너무 많은 join이 필요한 경우
             반 정규화를 활용하여 테이블에 속성을 추가 
             
             */
             
             
             
             /* 소녀시대가 부른 노래 검색 */
             
             
             
             /* 소녀시대 3집앨범의 수록곡을 확인하기 위한 쿼리문 
             
             
             
             
             /* list 테이블에 가수 이름을 저장하는 li_st_name을 추가하여(반정규화)
             
             
             
             /* 
             트리거와 프로시저 : 사용을 안한느것이 좋다고 한다.
             프로시저 : 사용자가 만든 함수로 호출하여 사용
             트리거   : 데이터가 추가, 수정, 삭제가 일어나는 경우 미리 지정된 작업이 자동으로 실행됨
             트리거
             delimiter 기호
             create trigger 트리거명 트리거 이벤트 on 테이블명
             for each row
             begin
             
				코드작성;
                end 기호
                delimiter;
				delimiter 기호 : 문장의 마지막을 알려주는 기호를 ; 대신 지정한 기호로 대체 
                - 코드작성부분에서 ; 이 나왓을때 실행하지 안도록 ; 을 무시하게 하기위해서 사용 
             
             
             */
             use portal;
  --           학생이 강의를 수강신청하면 해당 강의의 현재 정원이 1증가로 하는 트리거 
             drop trigger if exists insert_coures;
             delimiter 호잉
             create trigger insert_course after insert on course
             for each row
             
             begin
             update class
             set cl_now_count = cl_now_count + 1
             where cl_code = new.co_cl_code;
             
             end 호잉
             
             delimiter ;
             
             --  해당 데이터베이스의 트리거 확인 
             show triggers;
             
             
             
             use example;
             
           /* 주문 테이블에 주문내역이 추가되면 제품 테이블의 재고량이 변화는 트리거를 작성 */
           
           
  --           학생이 강의를 수강신청하면 해당 강의의 현재 정원이 1증가로 하는 트리거 
             drop trigger if exists insert_order;
             delimiter 시작
             create trigger insert_order after insert on `주문`
             for each row
             begin
             update `제품`
             set 재고량 = 재고량 - new.수량
             where 제품번호 = new.주문제품;
			end 시작
             
             delimiter ;
             
             
             -- 트리거 실행문에서 조건문 사용 해보기
             
                  drop trigger if exists test_order;
             delimiter 시작
             create trigger test_order after insert on `주문`
             for each row
             begin
	
			-- if문 문법
            -- 변수 선언(begin 바로 밑에 변수들을 모아서 선언해야함)
            declare 변수명 타입 default 초기값;
            -- 변수 선언시 변수명 앞에 _를 붙으면 좋다. 속성이름과 구분하기 위해 
            -- 변수 저장
            
             set 변수 명 = 값;
			declare _amount int default 0;
            declare _state varchar(10) default '' ; 
             set _amount = 10;
             set _amount = (select count(*) from 주문);
             if _amount > 10 then 
             set _state = '많다'
             elseif _amount > 5  then
             set _state = '적절'
             else
             set _state = '적음'
			end if ;
             
			end 시작
             
             delimiter ;
             
             /* 
             프로시저
             drop procedure if exists 프로시저명;
             delimiter 기호
             create procedure 프로시저명(
             { in | out} 변수명1,
             { in | out} 변수명2,
             ....
             )
             begin
             구현;
             end 기호
             delimiter ;
             
             */
             
             -- 프로시저 호출 
              -- call 프로시저명(변수들);
              주문
             
             drop procedure if exists addOrder;
             delimiter //
             create procedure addOrder(
              in _id varchar(20),
              in _product char(3),
              in _amount int,
              in _address varchar(30),
              in _date varchar(20)
			
             )
             begin
             declare _count int default 0;
             declare _order_num char(3);
			set _count = (select count(*) from 주문) + 1;
            set order_num = concat('o' , _count);
          -- set _order_num = 'o13';
           insert into `주문` values(_order_num, _id, _product, _amount, _address, _date);
			select * from `주문` ;
             end //
             delimiter ;
             
             
             call addOrder('pear', 'p01' , 15, '충북 청주시', '2021-06-01');
             
             
             
             
             
           
             
             
             
             
             