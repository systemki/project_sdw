/* 

insert into 테이블명[(속성1, 속성2,....속성n)]
values(값1, 값2, ..... 값n) [,(값1, 값2, .... 갑n)]

slect [all | distinct] 속성1, 속성2, .... 속성 n from 테이블 
where 조건
group by 속성 [having 조건]
group by 속성 [desc | asc];

update 테이블명
set
속성명1 = 값1,
where 조건;
업데이트 문은 조건이 없으면 모든 튜플에 대해 수정을 적용 student
update문제 조건절을 생략하면 mysql 워크벤치에서는 안정성을 위해 update문을 실행하지 않음
Edit > Preferece > SQl  editor
실행하라면 워크벤치 아닌 mysql 8.0 command like client로 접속해서 해당쿼를 실행하면 됨 

delete from 테이블명 [where 조건];
- 해당 조건을 만족하는 튜플을 삭제
- 조건이 생략되면 전체 튜플을 삭제 


*/

select * from student;
 
update student
set
st_name = '고길동' where st_num = '2020160001';



create table if not exists board(
bd_num int auto_increment,
bd_title varchar(50) not null,
bd_is_del char(1) not null default 'N',
primary key(bd_num)
);

-- 게시글 5개 등록 
insert into board(bd_title)
values('제목1'),('제목2'),('제목3'),('제목4'),('제목5');

select * from board;

-- 1번 게시글 삭제

update board set bd_is_del = 'Y' where bd_num =1;
-- 삭제 되지 않는 게시글 검색 
select * from board where bd_is_del = 'N';






