 create database fruit;
 
 
  use fruit;

CREATE TABLE `fruit` (

	`fr_name`	varchar(15),
	`fr_price`	int	not NULL default 0,
	`fr_unit`	varchar(10)	not NULL default 'box',
	`tr_amount`	int	NULL default 0,
    `fr_stock` int not null default 0,
	primary key(fr_name),
    check (fr_price >= 0 and fr_stock >= 0)
);

CREATE TABLE `trade` (
	`tr_num`	int	NOT NULL,
	`tr_amount`	int	NULL default 0,
	`tr_type`	varchar(4) not	NULL default'sell' ,
	`tr_price`	int	not NULL default 0,
	`tr_date`	datetime	not NULL default current_timestamp,
	`tr_fr_name`	varchar(15)	NOT NULL,
    primary key(tr_num),
    foreign key(tr_fr_name) references fruit(fr_name)
);
-- (a과수원에서) 사과 100상자 입고되었다. 상자당 가격은 10000원

insert into fruit values('사과',10000,'box',0);

select * from fruit;

insert into trade (tr_num, tr_amount, tr_type, tr_price, tr_fr_name)
values(1, 100, 'buy',1000000, '사과');


select * from trade;

update fruit set fr_amount =fr_amount + 100 where fr_name = '사과';

select * from fruit;
